/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventoris;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksi.Connect;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.sun.glass.events.KeyEvent;
import static inventoris.MenuUtama.dashboard;
import static inventoris.MenuUtama.divisi;
import static inventoris.MenuUtama.txtUserLogin;
import java.awt.event.MouseEvent;
import javax.swing.Timer;
import static koneksi.Connect.GetConnection;



/**
 *
 * @author PANASONIC
 */
public class FrmBarang extends javax.swing.JFrame {
    /**
     * Creates new form FrmBarang
     */
    private DefaultTableModel tabelDt;
    String sql=("");
    public FrmBarang() {        
        initComponents();
        Tampil_Jam();
        Tampil_Tanggal();
        tgl_db();
        tgl_db.setVisible(false);
        btnUpdate.setVisible(false);
        btnEditRows.setVisible(false);
        btnDeleteSelected.setVisible(false);
        btnSave.setVisible(false);
        txtQty.setVisible(false);
    }
    public void Tampil_Jam(){
        ActionListener taskPerformer = new ActionListener() {
 
        @Override
            public void actionPerformed(ActionEvent evt) {
            String nol_jam = "", nol_menit = "",nol_detik = "";
 
            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();
 
            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";
 
            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);
 
            jJam.setText(jam+":"+menit+":"+detik+"");
            }
        };
    new Timer(1000, taskPerformer).start();
    }   
 
public void Tampil_Tanggal() {
    java.util.Date tglsekarang = new java.util.Date();
    SimpleDateFormat smpdtfmt = new SimpleDateFormat("dd MMMMMMMMM yyyy", Locale.getDefault());
    String tanggal = smpdtfmt.format(tglsekarang);
    jTanggal.setText(tanggal);
}

public void tgl_db(){
    java.util.Date tglsekarang = new java.util.Date();
    SimpleDateFormat smpdtfmt = new SimpleDateFormat("yyyy/MM/dd", Locale.getDefault());
    String tanggal = smpdtfmt.format(tglsekarang);
    tgl_db.setText(tanggal);
}

public void editTabel(){
    DefaultTableModel dataModel = (DefaultTableModel) tabelData.getModel();
            
            // i = index tabel
            try {
               btnUpdate.setVisible(true);
               btnSave.setVisible(false);
               int i = tabelData.getSelectedRow();
               txtCode.setText(dataModel.getValueAt(i, 0).toString());
               txtDescription.setText(dataModel.getValueAt(i, 1).toString());
               txtSize.setText(dataModel.getValueAt(i, 2).toString());
               txtArticle.setText(dataModel.getValueAt(i, 3).toString());
               txtMerk.setText(dataModel.getValueAt(i, 4).toString());
               txtSellprice.setText(dataModel.getValueAt(i, 5).toString());
               txtQty.requestFocus();
            }catch (ArrayIndexOutOfBoundsException e) {
                JOptionPane.showMessageDialog(this, "Tabel Belum Dipilih", "Kesalahan", JOptionPane.WARNING_MESSAGE);
            }
}

public void updateTabel(){
    DefaultTableModel dataModel = (DefaultTableModel) tabelData.getModel();
    if(txtCode.getText().equals("") || txtDescription.getText().equals("") || txtSize.getText().equals("") || txtArticle.getText().equals("") || txtMerk.getText().equals("") || txtSellprice.getText().equals("") || txtQty.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Lengkapi Data Terlebih Dahulu");
            txtCode.requestFocus();
        }
        int i = tabelData.getSelectedRow();
         if(i >= 0){
             dataModel.setValueAt(txtCode.getText(), i, 0);
             dataModel.setValueAt(txtDescription.getText(), i, 1);
             dataModel.setValueAt(txtSize.getText(), i, 2);
             dataModel.setValueAt(txtArticle.getText(), i, 3);
             dataModel.setValueAt(txtMerk.getText(), i, 4);
             dataModel.setValueAt(txtSellprice.getText(), i, 5);
             dataModel.setValueAt(txtQty.getText(),i , 6);
             
             
             txtCode.setText("");
             txtDescription.setText("");
             txtSize.setText("");
             txtArticle.setText("");
             txtMerk.setText("");
             txtSellprice.setText("");
             txtQty.setText("");
             txtSellprice.setText("");
             txtCode.requestFocus();
             btnSave.setVisible(true);
             btnUpdate.setVisible(false);
         }else{
             JOptionPane.showMessageDialog(this, "Tabel Belum Dipilih", "Kesalahan", JOptionPane.WARNING_MESSAGE);
         }
}

public void addData(){
    if(txtCode.getText().equals("") || txtDescription.getText().equals("") || txtSize.getText().equals("") || txtArticle.getText().equals("") || txtMerk.getText().equals("") || txtSellprice.getText().equals("") || txtQty.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Lengkapi Data Terlebih Dahulu");
            txtCode.requestFocus();
        }else{
        DefaultTableModel dataModel = (DefaultTableModel) tabelData.getModel();
        if(txtCode.getText().equals(ABORT))
                btnDeleteSelected.setVisible(true);
                btnEditRows.setVisible(true);
                
                
                List list = new ArrayList<>();
                tabelData.setAutoCreateColumnsFromModel(true);
                list.add(txtCode.getText());
                list.add(txtDescription.getText());
                list.add(txtSize.getText());
                list.add(txtArticle.getText());
                list.add(txtMerk.getText());
                list.add(txtSellprice.getText());
                list.add(txtQty.getText());
                list.add(tgl_db.getText()+" "+jJam.getText());
                list.add(txtUseInput.getText());
                dataModel.addRow(list.toArray());
            
                txtCode.setText("");
                txtDescription.setText("");
                txtSize.setText("");
                txtArticle.setText("");
                txtMerk.setText("");
                txtSellprice.setText("");
                txtQty.setText("");
                txtSellprice.setText("");
                txtCode.requestFocus();
            
                int jml=dataModel.getRowCount();
                txtJmlRow.setText(""+jml);
    }
}

//public void sumQty(){
//    //deklarasi tabel
//    DefaultTableModel dataModel = (DefaultTableModel) tabelData.getModel();
//    
//    //variable baris dan kolom table
//    int i = tabelData.getRowCount();
//    int a = tabelData.getColumnCount();
//    
//    //variable menampung data yang sudah ada ditable
//    String skuOld = String.valueOf(dataModel.getValueAt(i, 0));
//    int qtyOld = (Integer) tabelData.getValueAt(i, 6);
//    
//    //variabel menampung data yang akan diinput ke table
//    String skuNew = txtCode.getText();
//    int qtyNew = Integer.parseInt(txtQty.getText());
//    
//    //kondisi jika sku_id yang akan diinput sudah ada maka menjumlahkan qty saja
//        qtyNew += qtyOld;
//             dataModel.setValueAt(txtCode.getText(), i, 0);
//             dataModel.setValueAt(txtDescription.getText(), i, 1);
//             dataModel.setValueAt(txtSize.getText(), i, 2);
//             dataModel.setValueAt(txtArticle.getText(), i, 3);
//             dataModel.setValueAt(txtMerk.getText(), i, 4);
//             dataModel.setValueAt(txtSellprice.getText(), i, 5);
//             dataModel.setValueAt(qtyNew,i, 6);
//    
//}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtCode = new javax.swing.JTextField();
        txtDescription = new javax.swing.JTextField();
        txtArticle = new javax.swing.JTextField();
        txtMerk = new javax.swing.JTextField();
        txtSellprice = new javax.swing.JTextField();
        txtQty = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelData = new javax.swing.JTable();
        btnSave = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        txtSize = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTanggal = new javax.swing.JLabel();
        jJam = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btnKembali = new javax.swing.JButton();
        txtJmlRow = new javax.swing.JTextField();
        btnDeleteSelected = new javax.swing.JButton();
        btnEditRows = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnAddCoretan = new javax.swing.JButton();
        txtInfoInputTable = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setText("CODE ITEM");

        jLabel2.setText("DESCRIPTION");

        jLabel3.setText("ARTICLE");

        jLabel4.setText("MERK");

        jLabel5.setText("SELL PRICE");

        jLabel6.setText("QTY");

        txtCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodeActionPerformed(evt);
            }
        });
        txtCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCodeKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodeKeyTyped(evt);
            }
        });

        txtSellprice.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSellpriceKeyPressed(evt);
            }
        });

        txtQty.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtQtyMouseClicked(evt);
            }
        });
        txtQty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtQtyKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtQtyKeyTyped(evt);
            }
        });

        tabelData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Code Item", "Description", "size","Article", "Merk", "Sell Price", "Qty", "Created date", "Created by"
            }
        ));
        tabelData.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tabelData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelDataMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelData);

        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        jLabel7.setText("Size");

        jTanggal.setText("jTanggal");

        jJam.setText("jJam");

        txtUseInput.setText("User Input");

        jLabel8.setIcon(new javax.swing.ImageIcon("D:\\Project\\java\\100px-Java_Logo.svg.png")); // NOI18N

        tgl_db.setForeground(new java.awt.Color(240, 240, 240));
        tgl_db.setText("tgl_for_db");

        btnKembali.setText("Back");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });

        txtDivisi.setText("Divisi");

        btnDeleteSelected.setText("Delete Selected");
        btnDeleteSelected.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteSelectedActionPerformed(evt);
            }
        });

        btnEditRows.setText("Edit Selected");
        btnEditRows.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditRowsActionPerformed(evt);
            }
        });

        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnAddCoretan.setText("ADDCORETAN");
        btnAddCoretan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddCoretanActionPerformed(evt);
            }
        });

        txtInfoInputTable.setText("jLabel9");

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(193, 193, 193)
                                .addComponent(btnAddCoretan)
                                .addGap(20, 20, 20)
                                .addComponent(jButton1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtQty, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtSellprice, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(105, 105, 105)
                                        .addComponent(txtInfoInputTable, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel7)
                            .addComponent(jLabel4))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(txtCode, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnCancel)
                                    .addGap(9, 9, 9))
                                .addComponent(txtDescription, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtSize, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtArticle, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMerk, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTanggal)
                    .addComponent(txtUseInput)
                    .addComponent(txtDivisi))
                .addGap(18, 18, 18)
                .addComponent(jJam)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tgl_db)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnSave)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnUpdate))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 826, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(14, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnKembali, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnEditRows, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDeleteSelected)
                        .addGap(18, 18, 18)
                        .addComponent(txtJmlRow, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTanggal)
                            .addComponent(jJam)
                            .addComponent(btnCancel)
                            .addComponent(tgl_db))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtUseInput))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(txtDivisi)
                                .addGap(138, 138, 138)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSave)
                                    .addComponent(btnUpdate)
                                    .addComponent(btnAddCoretan)
                                    .addComponent(jButton1)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtArticle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtMerk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtSellprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtInfoInputTable))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtQty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 354, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnKembali)
                    .addComponent(btnDeleteSelected)
                    .addComponent(btnEditRows)
                    .addComponent(txtJmlRow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(new java.awt.Dimension(888, 701));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
//buat function koneksi
    public Connection getConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
        }catch(ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        
        Connection con = null;
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost/inventory", "root", "");
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return con;
    }
    
    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        // TODO add your handling code here:
        //panggil koneksi
        Connection con = getConnection();
        Statement st;
        
        //deklarasi tabel
        DefaultTableModel model = (DefaultTableModel) tabelData.getModel();
        //start
        if(model.getRowCount()==0){
            JOptionPane.showMessageDialog(null, "Lengkapi Data Terlebih Dahulu");
            txtCode.requestFocus();
        }else{
            //cek jika database sudah ada
//            for(int a = 0; a < model.getRowCount(); a++){
//                String skua = model.getValueAt(a, 0).toString();
//                String qtya = model.getValueAt(a, 6).toString();
//                String sqlQueryA = "SELECT * FROM receive_item WHERE sku_id='"+skua+"'";
//            }
            
        
        try {
            st = con.createStatement();
            
            for (int i = 0; i < model.getRowCount(); i++){
                String sku = model.getValueAt(i, 0).toString();
                String desc = model.getValueAt(i, 1).toString();
                String size = model.getValueAt(i, 2).toString();
                String article = model.getValueAt(i, 3).toString();
                String merk = model.getValueAt(i, 4).toString();
                String qty = model.getValueAt(i, 6).toString();
                String sellprice = model.getValueAt(i, 5).toString();
                String createddate = model.getValueAt(i, 7).toString();
                String createdby = model.getValueAt(i, 8).toString();                
        //query masukkan row ke database        
                String sqlQuery = "INSERT INTO `receive_item`(`sku_id`, `sku_desc`, `size_code`, `article_desc`, `merk_desc`, `qty`, `sellprice`, `created_date`, `created_by`) VALUES ('"+sku+"','"+desc+"','"+size+"','"+article+"','"+merk+"','"+qty+"','"+sellprice+"','"+createddate+"','"+createdby+"')";
        //eksekusi query        
                st.addBatch(sqlQuery);
            }
        //jika sukses tampilkan jumlah row yang diinput    
            int[] rowsInserted = st.executeBatch();
            JOptionPane.showMessageDialog(rootPane, rowsInserted.length+" Row Berhasil Diinput Ke Database");
            model.setRowCount(0);
            txtCode.requestFocus();
        
        //jika gagal tampilkan pesan eror detailnya
        } catch (SQLException ex) {
            Logger.getLogger(FrmBarang.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
        txtCode.setText("");
        txtDescription.setText("");
        txtSize.setText("");
        txtArticle.setText("");
        txtMerk.setText("");
        txtSellprice.setText("");
        txtQty.setText("");
        txtCode.requestFocus();
        
    }//GEN-LAST:event_btnCancelActionPerformed

    private void txtCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodeActionPerformed

    private void txtCodeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodeKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER){
        try{
            Statement statement = (Statement)Connect.GetConnection().createStatement();
            
            ResultSet result=statement.executeQuery("SELECT * FROM mst_barang WHERE sku_id='" + txtCode.getText()+"'");
            if(result.next()){
                txtDescription.setText(result.getString("sku_desc"));
                txtSize.setText(result.getString("size_code"));
                txtArticle.setText(result.getString("article_desc"));
                txtMerk.setText(result.getString("merk_desc"));
                txtSellprice.setText(result.getString("sellprice"));
                
                btnEditRows.setVisible(true);
                btnDeleteSelected.setVisible(true);
                btnSave.setVisible(true);
                txtDescription.setEditable(false);
                txtSize.setEditable(false);
                txtArticle.setEditable(false);
                txtMerk.setEditable(false);
                txtSellprice.setEditable(false);
                txtQty.setVisible(true);
                txtQty.requestFocus();
                
            }else{
                JOptionPane.showMessageDialog(rootPane, "SKU Not Match");
                txtCode.setText("");
                txtQty.setText("");
                txtCode.requestFocus();
            }
        } catch(Exception e){
            JOptionPane.showMessageDialog(rootPane,"Gagal");
            this.dispose();
        }
        }
    }//GEN-LAST:event_txtCodeKeyPressed

    private void txtSellpriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSellpriceKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER){
         txtQty.requestFocus();   
        }
    }//GEN-LAST:event_txtSellpriceKeyPressed

    private void txtQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtQtyKeyPressed
        // TODO add your handling code here:
        
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            addData();
        }
    }//GEN-LAST:event_txtQtyKeyPressed

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        // TODO add your handling code here:
        new MenuUtama ().setVisible(true);
        txtUserLogin.setText(txtUseInput.getText());
        divisi.setText(txtDivisi.getText());
        if(txtDivisi.getText().trim().equals("USER")){
            dashboard.setEnabled(false);
        }else if(txtDivisi.getText().trim().equals("SUPERVISOR")){
            dashboard.setEnabled(false);
        }
        this.dispose();
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void btnDeleteSelectedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteSelectedActionPerformed
        // TODO add your handling code here:
        DefaultTableModel dataModel = (DefaultTableModel) tabelData.getModel();
         try {
            int x = tabelData.getSelectedRow();
            dataModel.removeRow(x);
            txtCode.requestFocus();
            int jml=dataModel.getRowCount();
            txtJmlRow.setText(""+jml);
        } catch (ArrayIndexOutOfBoundsException e) {
            JOptionPane.showMessageDialog(this, "Tabel Belum Dipilih", 
                    "Kesalahan", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnDeleteSelectedActionPerformed

    private void tabelDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelDataMouseClicked
        // TODO add your handling code here:
        
            
    }//GEN-LAST:event_tabelDataMouseClicked

    private void btnEditRowsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditRowsActionPerformed
        // TODO add your handling code here:
        editTabel();
    }//GEN-LAST:event_btnEditRowsActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
        updateTabel();
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnAddCoretanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddCoretanActionPerformed
        // TODO add your handling code here:
        DefaultTableModel dataModel = (DefaultTableModel) tabelData.getModel();
        String skuNew = txtCode.getText();
        int total = 0;
        
        for(int i = 0; i < dataModel.getRowCount(); i++){
            int qtyNew = Integer.parseInt(txtQty.getText());
            String skuOld = String.valueOf(dataModel.getValueAt(i, 0));
            int qtyOld = Integer.parseInt((String)dataModel.getValueAt(i, 6));
            String qtyBaru = Integer.toString(qtyNew);
            String qtyLama = Integer.toString(qtyOld);
            
            if(dataModel.getValueAt(i, 0).equals(txtCode.getText())){
                for(int a = 0; a < dataModel.getRowCount(); a++){
                    
                    total = qtyNew + qtyOld;
                    String ttl=Integer.toString(total);

                    dataModel.setValueAt(txtCode.getText(), a, 0);
                    dataModel.setValueAt(txtDescription.getText(), a, 1);
                    dataModel.setValueAt(txtSize.getText(), a, 2);        
                    dataModel.setValueAt(txtArticle.getText(), a, 3);        
                    dataModel.setValueAt(txtMerk.getText(), a, 4);        
                    dataModel.setValueAt(txtSellprice.getText(), a, 5);        
                    dataModel.setValueAt(ttl, a, 6);                

                    txtCode.setText("");
                    txtDescription.setText("");
                    txtSize.setText("");
                    txtArticle.setText("");
                    txtMerk.setText("");
                    txtSellprice.setText("");
                    txtQty.setText("");
                    txtCode.requestFocus();
                }
            }else{
                List list = new ArrayList<>();
                tabelData.setAutoCreateColumnsFromModel(true);
                list.add(txtCode.getText());
                list.add(txtDescription.getText());
                list.add(txtSize.getText());
                list.add(txtArticle.getText());
                list.add(txtMerk.getText());
                list.add(txtSellprice.getText());
                list.add(txtQty.getText());
                list.add(tgl_db.getText()+" "+jJam.getText());
                list.add(txtUseInput.getText());
                dataModel.addRow(list.toArray());
            
                txtCode.setText("");
                txtDescription.setText("");
                txtSize.setText("");
                txtArticle.setText("");
                txtMerk.setText("");
                txtSellprice.setText("");
                txtQty.setText("");
                txtSellprice.setText("");
                txtCode.requestFocus();
            
                int jml=dataModel.getRowCount();
                txtJmlRow.setText(""+jml);
        }
        
            
            
            
        
        }
    }//GEN-LAST:event_btnAddCoretanActionPerformed

    private void txtCodeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodeKeyTyped
        // TODO add your handling code here:
        char enter = evt.getKeyChar();
        if(!(Character.isDigit(enter))){
            evt.consume();
        }
    }//GEN-LAST:event_txtCodeKeyTyped

    private void txtQtyKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtQtyKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQtyKeyTyped

    private void txtQtyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtQtyMouseClicked
        // TODO add your handling code here
        int clicked = evt.getClickCount();
        if(!(Character.isDigit(clicked))){
            txtCode.requestFocus();
            evt.consume();
        }
    }//GEN-LAST:event_txtQtyMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmBarang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddCoretan;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDeleteSelected;
    private javax.swing.JButton btnEditRows;
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jJam;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jTanggal;
    private javax.swing.JTable tabelData;
    public static final javax.swing.JLabel tgl_db = new javax.swing.JLabel();
    private javax.swing.JTextField txtArticle;
    private javax.swing.JTextField txtCode;
    private javax.swing.JTextField txtDescription;
    public static final javax.swing.JLabel txtDivisi = new javax.swing.JLabel();
    private javax.swing.JLabel txtInfoInputTable;
    private javax.swing.JTextField txtJmlRow;
    private javax.swing.JTextField txtMerk;
    private javax.swing.JTextField txtQty;
    private javax.swing.JTextField txtSellprice;
    private javax.swing.JTextField txtSize;
    public static final javax.swing.JLabel txtUseInput = new javax.swing.JLabel();
    // End of variables declaration//GEN-END:variables
}
